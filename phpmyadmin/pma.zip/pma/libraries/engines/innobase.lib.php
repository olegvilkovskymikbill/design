<?php
/* vim: set expandtab sw=4 ts=4 sts=4: */
/**
 *
 * @package phpMyAdmin-Engines
 */

/**
 *
 */
include_once './libraries/engines/innodb.lib.php';

/**
 *
 * @package phpMyAdmin-Engines
 */
class PMA_StorageEngine_innobase extends PMA_StorageEngine_innodb {}

?>
