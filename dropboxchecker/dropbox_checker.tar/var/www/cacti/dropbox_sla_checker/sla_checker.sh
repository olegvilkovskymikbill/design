#!/usr/bin/env bash

cd /var/www/cacti/dropbox_sla_checker

echo "" > ./index.html
echo "<!doctype html>
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/main.css">
    </head>
    <body>" >> ./index.html

echo "<div class=\"divTable\">
<div class=\"divTableBody\">" >> ./index.html


echo "<div class=\"divTableRow\">
<div class=\"divTableCellSLA\">SkySystems</div>
<div class=\"divTableCell\">Size</div>
<div class=\"divTableCell\">Filename</div>
<div class=\"divTableCell\">Date Time (UTC)</div>
</div>" >> ./index.html
./dropbox_sla_checker.sh -f ./apikeys/skysystems -h list >> ./index.html
echo "</div></div>" >> ./index.html

########################################################################

echo "<div class=\"divTable\">
<div class=\"divTableBody\">" >> ./index.html
echo "<div class=\"divTableRow\">
<div class=\"divTableCellSLA\">Zenit</div>
<div class=\"divTableCell\">Size</div>
<div class=\"divTableCell\">Filename</div>
<div class=\"divTableCell\">Date Time (UTC)</div>
</div>" >> ./index.html
./dropbox_sla_checker.sh -f ./apikeys/zenit -h list >> ./index.html
echo "</div></div>" >> ./index.html

########################################################################

echo "<div class=\"divTable\">
<div class=\"divTableBody\">" >> ./index.html
echo "<div class=\"divTableRow\">
<div class=\"divTableCellSLA\">Fractal</div>
<div class=\"divTableCell\">Size</div>
<div class=\"divTableCell\">Filename</div>
<div class=\"divTableCell\">Date Time (UTC)</div>
</div>" >> ./index.html
./dropbox_sla_checker.sh -f ./apikeys/fractal -h list >> ./index.html
echo "</div></div>" >> ./index.html

########################################################################

echo "<div class=\"divTable\">
<div class=\"divTableBody\">" >> ./index.html
echo "<div class=\"divTableRow\">
<div class=\"divTableCellSLA\">Xlan</div>
<div class=\"divTableCell\">Size</div>
<div class=\"divTableCell\">Filename</div>
<div class=\"divTableCell\">Date Time (UTC)</div>
</div>" >> ./index.html
./dropbox_sla_checker.sh -f ./apikeys/xlan -h list >> ./index.html
echo "</div></div>" >> ./index.html

########################################################################

echo "<div class=\"divTable\">
<div class=\"divTableBody\">" >> ./index.html
echo "<div class=\"divTableRow\">
<div class=\"divTableCellSLA\">FoxNet</div>
<div class=\"divTableCell\">Size</div>
<div class=\"divTableCell\">Filename</div>
<div class=\"divTableCell\">Date Time (UTC)</div>
</div>" >> ./index.html
./dropbox_sla_checker.sh -f ./apikeys/foxnet -h list >> ./index.html
echo "</div></div>" >> ./index.html

########################################################################

echo "<div class=\"divTable\">
<div class=\"divTableBody\">" >> ./index.html
echo "<div class=\"divTableRow\">
<div class=\"divTableCellSLA\">NVF</div>
<div class=\"divTableCell\">Size</div>
<div class=\"divTableCell\">Filename</div>
<div class=\"divTableCell\">Date Time (UTC)</div>
</div>" >> ./index.html
./dropbox_sla_checker.sh -f ./apikeys/nvf -h list >> ./index.html
echo "</div></div>" >> ./index.html

########################################################################

echo "<div class=\"divTable\">
<div class=\"divTableBody\">" >> ./index.html
echo "<div class=\"divTableRow\">
<div class=\"divTableCellSLA\">CID</div>
<div class=\"divTableCell\">Size</div>
<div class=\"divTableCell\">Filename</div>
<div class=\"divTableCell\">Date Time (UTC)</div>
</div>" >> ./index.html
./dropbox_sla_checker.sh -f ./apikeys/cid -h list >> ./index.html
echo "</div></div>" >> ./index.html

########################################################################


echo "<div class=\"divTable\">
<div class=\"divTableBody\">" >> ./index.html
echo "<div class=\"divTableRow\">
<div class=\"divTableCellSLA\">Wi-Fi House</div>
<div class=\"divTableCell\">Size</div>
<div class=\"divTableCell\">Filename</div>
<div class=\"divTableCell\">Date Time (UTC)</div>
</div>" >> ./index.html
./dropbox_sla_checker.sh -f ./apikeys/wifihouse -h list >> ./index.html
echo "</div></div>" >> ./index.html

########################################################################

echo "<div class=\"divTable\">
<div class=\"divTableBody\">" >> ./index.html
echo "<div class=\"divTableRow\">
<div class=\"divTableCellSLA\">StarLine</div>
<div class=\"divTableCell\">Size</div>
<div class=\"divTableCell\">Filename</div>
<div class=\"divTableCell\">Date Time (UTC)</div>
</div>" >> ./index.html
./dropbox_sla_checker.sh -f ./apikeys/starline -h list >> ./index.html
echo "</div></div>" >> ./index.html

########################################################################

echo "<div class=\"divTable\">
<div class=\"divTableBody\">" >> ./index.html
echo "<div class=\"divTableRow\">
<div class=\"divTableCellSLA\">DDS</div>
<div class=\"divTableCell\">Size</div>
<div class=\"divTableCell\">Filename</div>
<div class=\"divTableCell\">Date Time (UTC)</div>
</div>" >> ./index.html
./dropbox_sla_checker.sh -f ./apikeys/dds -h list >> ./index.html
echo "</div></div>" >> ./index.html
######################################################################
echo "<div class=\"divTable\">
<div class=\"divTableBody\">" >> ./index.html
echo "<div class=\"divTableRow\">
<div class=\"divTableCellSLA\">ITLux</div>
<div class=\"divTableCell\">Size</div>
<div class=\"divTableCell\">Filename</div>
<div class=\"divTableCell\">Date Time (UTC)</div>
</div>" >> ./index.html
./dropbox_sla_checker.sh -f ./apikeys/itlux -h list >> ./index.html
echo "</div></div>" >> ./index.html
######################################################################
echo "<div class=\"divTable\">
<div class=\"divTableBody\">" >> ./index.html
echo "<div class=\"divTableRow\">
<div class=\"divTableCellSLA\">Voronezh/Bobrov</div>
<div class=\"divTableCell\">Size</div>
<div class=\"divTableCell\">Filename</div>
<div class=\"divTableCell\">Date Time (UTC)</div>
</div>" >> ./index.html
./dropbox_sla_checker.sh -f ./apikeys/voronezh -h list >> ./index.html
echo "</div></div>" >> ./index.html
######################################################################
echo "<div class=\"divTable\">
<div class=\"divTableBody\">" >> ./index.html
echo "<div class=\"divTableRow\">
<div class=\"divTableCellSLA\">Kosmos</div>
<div class=\"divTableCell\">Size</div>
<div class=\"divTableCell\">Filename</div>
<div class=\"divTableCell\">Date Time (UTC)</div>
</div>" >> ./index.html
./dropbox_sla_checker.sh -f ./apikeys/kosmos -h list >> ./index.html
echo "</div></div>" >> ./index.html
######################################################################
echo "<div class=\"divTable\">
<div class=\"divTableBody\">" >> ./index.html
echo "<div class=\"divTableRow\">
<div class=\"divTableCellSLA\">Vistlink</div>
<div class=\"divTableCell\">Size</div>
<div class=\"divTableCell\">Filename</div>
<div class=\"divTableCell\">Date Time (UTC)</div>
</div>" >> ./index.html
./dropbox_sla_checker.sh -f ./apikeys/vistlink -h list >> ./index.html
echo "</div></div>" >> ./index.html
######################################################################
echo "<div class=\"divTable\">
<div class=\"divTableBody\">" >> ./index.html
echo "<div class=\"divTableRow\">
<div class=\"divTableCellSLA\">Line-New</div>
<div class=\"divTableCell\">Size</div>
<div class=\"divTableCell\">Filename</div>
<div class=\"divTableCell\">Date Time (UTC)</div>
</div>" >> ./index.html
./dropbox_sla_checker.sh -f ./apikeys/linenew -h list >> ./index.html
echo "</div></div>" >> ./index.html
######################################################################
echo "<div class=\"divTable\">
<div class=\"divTableBody\">" >> ./index.html
echo "<div class=\"divTableRow\">
<div class=\"divTableCellSLA\">Cifratel</div>
<div class=\"divTableCell\">Size</div>
<div class=\"divTableCell\">Filename</div>
<div class=\"divTableCell\">Date Time (UTC)</div>
</div>" >> ./index.html
./dropbox_sla_checker.sh -f ./apikeys/cifratel -h list >> ./index.html
echo "</div></div>" >> ./index.html
######################################################################
echo "<div class=\"divTable\">
<div class=\"divTableBody\">" >> ./index.html
echo "<div class=\"divTableRow\">
<div class=\"divTableCellSLA\">A-Com</div>
<div class=\"divTableCell\">Size</div>
<div class=\"divTableCell\">Filename</div>
<div class=\"divTableCell\">Date Time (UTC)</div>
</div>" >> ./index.html
./dropbox_sla_checker.sh -f ./apikeys/acom -h list >> ./index.html
echo "</div></div>" >> ./index.html
######################################################################

echo "<div class=\"divTable\">
<div class=\"divTableBody\">" >> ./index.html
echo "<div class=\"divTableRow\">
<div class=\"divTableCellSLA\">Plitos</div>
<div class=\"divTableCell\">Size</div>
<div class=\"divTableCell\">Filename</div>
<div class=\"divTableCell\">Date Time (UTC)</div>
</div>" >> ./index.html
./dropbox_sla_checker.sh -f ./apikeys/kozova -h list /Plitos >> ./index.html
echo "</div></div>" >> ./index.html

########################################################################

echo "<div class=\"divTable\">
<div class=\"divTableBody\">" >> ./index.html
echo "<div class=\"divTableRow\">
<div class=\"divTableCellSLA\">Talant</div>
<div class=\"divTableCell\">Size</div>
<div class=\"divTableCell\">Filename</div>
<div class=\"divTableCell\">Date Time (UTC)</div>
</div>" >> ./index.html
./dropbox_sla_checker.sh -f ./apikeys/kozova -h list /Talant >> ./index.html
echo "</div></div>" >> ./index.html

########################################################################


echo "</body>" >> ./index.html