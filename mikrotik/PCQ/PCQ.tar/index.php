<?php
require_once('Mikrotik.php');

$config_file='../../app/etc/config.xml';
if (file_exists($config_file)) {
    $xml = simplexml_load_file($config_file);
    $TIME_ZONE           = (string) $xml->parameters->timezone;
    $CONF_MYSQL_HOST     = (string) $xml->parameters->mysql->host;
    $CONF_MYSQL_USERNAME = (string) $xml->parameters->mysql->username;
    $CONF_MYSQL_PASSWORD = (string) $xml->parameters->mysql->password;
    $CONF_MYSQL_DBNAME   = (string) $xml->parameters->mysql->dbname;

} else {
    die("config not found");
}

if(isset($TIME_ZONE))
    date_default_timezone_set($TIME_ZONE);
else
    date_default_timezone_set('Europe/Kiev');

	
$db = new PDO( "mysql:host={$CONF_MYSQL_HOST};dbname={$CONF_MYSQL_DBNAME}", $CONF_MYSQL_USERNAME, $CONF_MYSQL_PASSWORD,
			array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES koi8r") );
			
$mikrotiks	= array();

$GET_NAS=	'SELECT 
			   id, nasname, naslogin, naspass, description, mikver
			 FROM 
			   radnas
			 WHERE 
			   shapertype=6';

			   
$res = $db->query($GET_NAS, PDO::FETCH_LAZY);
			
foreach ($res as $row)
{
	$mk = new Mikrotik($row["id"]);
	$mk->add_mikrotik($row["id"], $row["nasname"], $row["naslogin"], $row["naspass"], $row["description"], $row["mikver"]);
	array_push($mikrotiks, $mk);
}




echo " ========== Обновление шейперов PCQ =============== \n";
foreach($mikrotiks as $mk)
{
	echo "ID:".$mk->get_id()." IP:".$mk->get_ip()."\n";
	
	if ($mk->check_ssh()==1 && $mk->check_ftp() ==1 && $mk->get_ip() != "localhost")
		echo "Статус NAS сервера: Включен , версия:{$mk->get_ver()} \n";
	else
		echo "Статус NAS сервера: Не доступна одна из служб ssh/ftp \n";
			
	if($mk->get_ip() != "localhost" && $mk->enabled())
	{
		$get_packets="SELECT gid FROM packetsnas WHERE nasid={$mk->get_id()}";
		
		$res = $db->query($get_packets, PDO::FETCH_LAZY);
		
		$rules = array();
		
		array_push($rules, $mk->create_clear_old());
		
		foreach($res as $pkt) 
		{
			//echo "Создаю шейпера для тарифа {$pkt["gid"]} \n";
			
			$night = "SELECT do_shapers_day_night, dop_do_interval2, dop_do_interval3, world_shaper_do, do_turbo FROM packets WHERE gid={$pkt["gid"]}";
			$night_result = $db->query($night, PDO::FETCH_LAZY);
			
			$world_en  = 0;
			$night_en1 = 0;
			$night_en2 = 0;
			$night_en3 = 0;
			$turbo_en = 0;
			
			foreach($night_result as $ne)
			{
				$turbo_en  = $ne["do_turbo"];
				$world_en  = $ne["world_shaper_do"];
				$night_en1 = $ne["do_shapers_day_night"];
				$night_en2 = $ne["dop_do_interval2"];
				$night_en3 = $ne["dop_do_interval3"];
			}
			
			$packet_query = "SELECT mikrotik_addr_list";
			
			if($turbo_en)
			{
					$packet_query .= ", turbo_speed_in, turbo_speed_out";
			}
			
			if($world_en)
			{
					$packet_query .= "
							,mikrotik_addr_list,
							speed_rate,
							speed_burst,
							speed_mik_burst_in,
							speed_mik_burst_out,
							speed_mik_treshold_in,
							speed_mik_treshold_out,
							speed_mik_burst_time_in,
							speed_mik_burst_time_out,
							shaper_prio,
							world_speed_in,
							world_speed_out,
							world_speed_burst_in,
							world_speed_burst_out,
							world_speed_treshold_in,
							world_speed_treshold_out,
							world_speed_burst_time_in,
							world_speed_burst_time_out,
							world_speed_prio";
						
			}
			
			if($night_en1)
			{
					$packet_query .= "
						,dop_interval1_time1,
						dop_interval1_time2,
						dop_interval1_speed_in,
						dop_interval1_speed_out,
						dop_interval1_burst_limit_in,
						dop_interval1_burst_limit_out,
						dop_interval1_burst_threshold_in,
						dop_interval1_burst_threshold_out,
						dop_interval1_burst_time_in,
						dop_interval1_burst_time_out,
						dop_interval1_prio";
									
				if($night_en2)
				{
					$packet_query .= "
						,dop_interval2_time1,
						dop_interval2_time2,
						dop_interval2_speed_in,
						dop_interval2_speed_out,
						dop_interval2_burst_limit_in,
						dop_interval2_burst_limit_out,
						dop_interval2_burst_threshold_in,
						dop_interval2_burst_threshold_out,
						dop_interval2_burst_time_in,
						dop_interval2_burst_time_out,
						dop_interval2_prio";
				}
				
				if($night_en3)
				{
					$packet_query .= "
						,dop_interval3_time1,
						dop_interval3_time2,
						dop_interval3_speed_in,
						dop_interval3_speed_out,
						dop_interval3_burst_limit_in,
						dop_interval3_burst_limit_out,
						dop_interval3_burst_threshold_in,
						dop_interval3_burst_threshold_out,
						dop_interval3_burst_time_in,
						dop_interval3_burst_time_out,
						dop_interval3_prio";
				}
				
				$packet_query .= " FROM packets WHERE gid={$pkt["gid"]}";
			}		
			else
			{
				$packet_query .= "
						,speed_rate,
						speed_burst,
						speed_mik_burst_in,
						speed_mik_burst_out,
						speed_mik_treshold_in,
						speed_mik_treshold_out,
						speed_mik_burst_time_in,
						speed_mik_burst_time_out,
						shaper_prio
					FROM
						packets
					WHERE
						gid={$pkt["gid"]}";
			}
			
			$data_ = $db->query($packet_query, PDO::FETCH_LAZY);
			
			foreach($data_ as $data)
			{
				if($data["mikrotik_addr_list"] == "")
					break;
					
				/* Mangle */
				if($turbo_en)
				{
					if($world_en)
						array_push($rules, $mk->create_turbo_country_mangle($data["mikrotik_addr_list"]));
					array_push($rules, $mk->create_turbo_mangle($data["mikrotik_addr_list"]));
				}	

				if($world_en)
					array_push($rules, $mk->create_country_mangle($data["mikrotik_addr_list"]));
				array_push($rules, $mk->create_mangle($data["mikrotik_addr_list"]));
				
				/* Queue type */
				if($world_en)
					array_push($rules, $mk->create_queque_type($data["mikrotik_addr_list"], "_country", "", $data["world_speed_in"],  $data["world_speed_out"], $data["world_speed_burst_in"], $data["world_speed_burst_out"], $data["world_speed_treshold_in"], $data["world_speed_treshold_out"], $data["world_speed_burst_time_in"], $data["world_speed_burst_time_out"]));
				if($turbo_en)
					array_push($rules, $mk->create_queque_type($data["mikrotik_addr_list"], "_turbo", "", $data["turbo_speed_in"],  $data["turbo_speed_out"], 0, 0, 0, 0, 0, 0));	
				if($night_en1)
				{	
					array_push($rules, $mk->create_queque_type($data["mikrotik_addr_list"], "", "_interval1", $data["dop_interval1_speed_in"],  $data["dop_interval1_speed_out"], $data["dop_interval1_burst_limit_in"], $data["dop_interval1_burst_limit_out"], $data["dop_interval1_burst_threshold_in"], $data["dop_interval1_burst_threshold_out"], $data["dop_interval1_burst_time_in"], $data["dop_interval1_burst_time_out"])); 
					if($night_en2)
						array_push($rules, $mk->create_queque_type($data["mikrotik_addr_list"], "", "_interval2", $data["dop_interval2_speed_in"],  $data["dop_interval2_speed_out"], $data["dop_interval2_burst_limit_in"], $data["dop_interval2_burst_limit_out"], $data["dop_interval2_burst_threshold_in"], $data["dop_interval2_burst_threshold_out"], $data["dop_interval2_burst_time_in"], $data["dop_interval2_burst_time_out"]));
					if($night_en3)
						array_push($rules, $mk->create_queque_type($data["mikrotik_addr_list"], "", "_interval3", $data["dop_interval3_speed_in"],  $data["dop_interval3_speed_out"], $data["dop_interval3_burst_limit_in"], $data["dop_interval3_burst_limit_out"], $data["dop_interval3_burst_threshold_in"], $data["dop_interval3_burst_threshold_out"], $data["dop_interval3_burst_time_in"], $data["dop_interval3_burst_time_out"]));
				}
				else
					array_push($rules, $mk->create_queque_type($data["mikrotik_addr_list"], "", "", $data["speed_rate"],  $data["speed_burst"], $data["speed_mik_burst_in"], $data["speed_mik_burst_out"], $data["speed_mik_treshold_in"], $data["speed_mik_treshold_out"], $data["speed_mik_burst_time_in"], $data["speed_mik_burst_time_out"]));

		
				/* Simple Queue */
				if($world_en)
					array_push($rules, $mk->create_queque_simple($data["mikrotik_addr_list"], "_country", "", "0s", "1d", $data["world_speed_prio"]));
				if($turbo_en)
					array_push($rules, $mk->create_queque_simple($data["mikrotik_addr_list"], "_turbo", "", "0s", "1d", 1));
				if($night_en1)
				{ 
					array_push($rules, $mk->create_queque_simple($data["mikrotik_addr_list"], "", "_interval1", $data["dop_interval1_time1"], $data["dop_interval1_time2"], $data["dop_interval1_prio"])); 
					if($night_en2)
						array_push($rules, $mk->create_queque_simple($data["mikrotik_addr_list"], "", "_interval2", $data["dop_interval2_time1"], $data["dop_interval2_time2"], $data["dop_interval2_prio"]));
					if($night_en3)
						array_push($rules, $mk->create_queque_simple($data["mikrotik_addr_list"], "", "_interval3", $data["dop_interval3_time1"], $data["dop_interval3_time2"], $data["dop_interval3_prio"]));
				}
				else
					array_push($rules, $mk->create_queque_simple($data["mikrotik_addr_list"], "", "", "0s", "1d", $data["shaper_prio"])); 
			}
		}
		
		make_file($mk->get_id(), $rules);
	}
}
/*** Конец ***/



function make_file($id, $content)
{
	$file_name="mikrotik_".$id.".rsc";
	
	if (!is_writable ($file_name)) {
		$fp = fopen ($file_name, "w+");
		fclose($fp);
	}
	
	if(file_exists($file_name))
		file_put_contents($file_name, "");
		
	foreach($content as $rule)
	{
		file_put_contents($file_name, $rule, FILE_APPEND);
	}
}

echo "Загрузка и приминение скрипта на NASах...\n";

// Функция загрузки скрипта на микротик
// TODO: добавить пасивный режим
function ftp_upload($ftp_server, $ftp_user_name, $ftp_user_pass, $file_in, $file_out)
{
	$conn_id = ftp_connect($ftp_server);
	$login_result = ftp_login($conn_id, $ftp_user_name, $ftp_user_pass);

	if ((!$conn_id) || (!$login_result)) {
		echo "No connect with $ftp_server via $ftp_user_name!\n";
		//			exit;
	}
	
	ftp_pasv($conn_id, true);
	
	$upload = ftp_put($conn_id, $file_out, $file_in, FTP_BINARY);
	
	if (!$upload) {
		echo "Error upload!\n";
	}
	ftp_close($conn_id);
}


// Заходим по FTP и SSH, закидываем и применяем скрипт на каждом микротике
foreach($mikrotiks as $mk)
{
	if($mk->enabled())
	{
		$nas_ip=$mk->get_ip();
		$nas_login=$mk->get_user();
		$nas_pass=$mk->get_pass();

		$file_out='mikrotik_'.$mk->get_id().'.rsc';
		$file_exec=$file_out;
		ftp_upload($nas_ip,$nas_login,$nas_pass,$file_out,$file_out);

		$command='import '.$file_exec;

		$ssh='/usr/bin/ssh '.$nas_login.'@'.$nas_ip;
		$mik_ssh='/usr/bin/sudo -u root '.$ssh.' ';
		exec($mik_ssh."$command"." &>/dev/null 2>&1");
	}
}

echo "Готово!\n";


	/*
	PCQ:
	адрес лист				mikrotik_addr_list
	
	Стандартный шейпер
		входящая			speed_rate
		исходящая			speed_burst
		бруст входящая		speed_mik_burst_in
		бурст исходящая		speed_mik_burst_out
		бурст размер вход	speed_mik_treshold_in
		бурст размер исход	speed_mik_treshold_out
		бурст время вход	speed_mik_burst_time_in
		бурст время исход	speed_mik_burst_time_out
		приоритет			shaper_prio
	
	Шейпер страна			world_shaper_do
		входящая			world_speed_in
		исходящая			world_speed_out
		бруст входящей		world_speed_burst_in
		бруст исходящей		world_speed_burst_out
		бруст размер вход	world_speed_treshold_in
		бруст размер выход	world_speed_treshold_out
		бруст время вход	world_speed_burst_time_in
		бруст время выход	world_speed_burst_time_out
		приоритет			world_speed_prio
	
	Турбо					do_turbo
		входящая			turbo_speed_in
		исходящая			turbo_speed_out
		
	День ночь активна		do_shapers_day_night
		время старт			dop_interval1_time1
		время стоп			dop_interval1_time2
		входящая			dop_interval1_speed_in
		исходящая			dop_interval1_speed_out
		бруст входящей		dop_interval1_burst_limit_in
		бруст исходящей		dop_interval1_burst_limit_out
		бруст размер вход	dop_interval1_burst_threshold_in
		бруст размер выход	dop_interval1_burst_threshold_out
		бруст время вход	dop_interval1_burst_time_in
		бруст время выход	dop_interval1_burst_time_out
		приоритет			dop_interval1_prio
		
	Интервал 2				dop_do_interval2
		время старт			dop_interval2_time1
		время стоп			dop_interval2_time2
		входящая			dop_interval2_speed_in
		исходящая			dop_interval2_speed_out
		бруст входящей		dop_interval2_burst_limit_in
		бруст исходящей		dop_interval2_burst_limit_out
		бруст размер вход	dop_interval2_burst_threshold_in
		бруст размер выход	dop_interval2_burst_threshold_out
		бруст время вход	dop_interval2_burst_time_in
		бруст время выход	dop_interval2_burst_time_out
		приоритет			dop_interval2_prio
		
	Интервал 3				dop_do_interval3
		время старт			dop_interval3_time1
		время стоп			dop_interval3_time2
		входящая			dop_interval3_speed_in
		исходящая			dop_interval3_speed_out
		бруст входящей		dop_interval3_burst_limit_in
		бруст исходящей		dop_interval3_burst_limit_out
		бруст размер вход	dop_interval3_burst_threshold_in
		бруст размер выход	dop_interval3_burst_threshold_out
		бруст время вход	dop_interval3_burst_time_in
		бруст время выход	dop_interval3_burst_time_out
		приоритет			dop_interval3_prio
	*/
?>


