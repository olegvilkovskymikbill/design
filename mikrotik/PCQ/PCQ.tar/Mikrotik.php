<?php

class Mikrotik
{
	private $mk_id;
	private $mk_ip;
	private $mk_user;
	private $mk_pass;
	private $mk_ver;
	private $mk_iface;
	 
	private $ssh = 0;
	private $ftp = 0;
	private $enabled = false;
	
	public function add_mikrotik($id, $ip, $user, $pass, $iface, $ver)
	{
		$this->mk_id 	= $id;
		$this->mk_ip 	= $ip;
		$this->mk_user 	= $user;
		$this->mk_pass 	= $pass;
		$this->mk_iface = $iface;
		$this->mk_ver	= $ver;
	}
	
	public function get_id()
	{
		return $this->mk_id;
	}
	
	public function get_ip()
	{
		return $this->mk_ip;
	}
	
	public function get_user()
	{
		return $this->mk_user;
	}
	
	public function get_pass()
	{
		return $this->mk_pass;
	}
	
	public function get_iface()
	{
		return $this->mk_iface;
	}
	
	public function get_ver()
	{
		return $this->mk_ver;
	}
	
	public function enabled()
	{
		if($this->ssh == 1 && $this->ftp == 1)
			$this->enabled = true;
		return $this->enabled;
	}
	
	public function check_ssh()
	{
		if(!function_exists('fsockopen'))
		{ echo 'fsockopen не работает!'; return; }
		$tests = array(22 => $this->mk_ip);
		
		foreach($tests as $port => $server)
		{
			//Соединяемся
			$fp = @fsockopen($server,$port,$errno,$errstr,1);

			if($fp)
			{ 
				fclose($fp);
				$this->ssh = 1;
				return 1;
			}
			else
				return 0;
		}
	}
	
	public function check_ftp()
	{
		if(!function_exists('fsockopen'))
		{ echo 'fsockopen не работает!'; return; }
		$tests = array(21 => $this->mk_ip);
		
		foreach($tests as $port => $server)
		{
			//Соединяемся
			$fp = @fsockopen($server,$port,$errno,$errstr,1);

			if($fp)
			{ 
				fclose($fp); 
				$this->ftp = 1;
				return 1;
			}
			else
				return 0;
		}
	}
	
	public function create_clear_old()
	{
		$rules=array();
		/* Удаляем старые записи */
		array_push($rules,"/ip firewall mangle remove [find comment~\"mikbill_auto\"]\n");
		array_push($rules,"/queue simple remove [find comment~\"mikbill_auto\"]\n");
		array_push($rules,"/queue tree remove [find comment~\"mikbill_auto\"]\n");
		array_push($rules,"/queue type remove [find name~\"mikbill.\"]\n");
		
		return $rules;
	}
	
	public function create_mangle($addr_list)
	{
		$rules=array();
		
		array_push ( $rules, "/ip firewall mangle\n" );
		/* Маркировка входящего трафика */
		array_push ( $rules, "add action=mark-packet chain=prerouting comment=mikbill_auto-{$addr_list}-OUT disabled=no \\\n" );
		array_push ( $rules, "	new-packet-mark={$addr_list}-OUT passthrough=no src-address-list={$addr_list}\n" );
		/* Маркировка исходящего трафика */
		array_push ( $rules, "add action=mark-packet chain=postrouting comment=mikbill_auto-{$addr_list}-IN disabled=no \\\n" );
		array_push ( $rules, "	new-packet-mark={$addr_list}-IN passthrough=no dst-address-list={$addr_list}\n" );
		
		return $rules;
	}
	
	public function create_turbo_mangle($addr_list)
	{
		$rules=array();
		
		array_push ( $rules, "/ip firewall mangle\n" );
		/* Маркировка входящего трафика */
		array_push ( $rules, "add action=mark-packet chain=prerouting comment=mikbill_auto-{$addr_list}-OUT_turbo disabled=no \\\n" );
		array_push ( $rules, "	new-packet-mark={$addr_list}-OUT_turbo passthrough=no src-address-list={$addr_list}_turbo\n" );
		/* Маркировка исходящего трафика */
		array_push ( $rules, "add action=mark-packet chain=postrouting comment=mikbill_auto-{$addr_list}-IN_turbo disabled=no \\\n" );
		array_push ( $rules, "	new-packet-mark={$addr_list}-IN_turbo passthrough=no dst-address-list={$addr_list}_turbo\n" );
		
		return $rules;
	}
	
	public function create_turbo_country_mangle($addr_list)
	{
		$rules=array();
		
		array_push ( $rules, "/ip firewall mangle\n" );
		/* Маркировка входящего трафика */
		array_push ( $rules, "add action=mark-packet chain=prerouting comment=mikbill_auto-{$addr_list}-OUT_country_turbo disabled=no \\\n" );
		array_push ( $rules, "	new-packet-mark={$addr_list}-OUT_country passthrough=no src-address-list={$addr_list}_turbo dst-address-list=country\n" );
		/* Маркировка исходящего трафика */
		array_push ( $rules, "add action=mark-packet chain=postrouting comment=mikbill_auto-{$addr_list}-IN_country_turbo disabled=no \\\n" );
		array_push ( $rules, "	new-packet-mark={$addr_list}-IN_country passthrough=no dst-address-list={$addr_list}_turbo src-address-list=country\n" );
		
		return $rules;
	}
	
	public function create_country_mangle($addr_list)
	{
		$rules=array();
		
		array_push ( $rules, "/ip firewall mangle\n" );
		/* Маркировка входящего трафика */
		array_push ( $rules, "add action=mark-packet chain=prerouting comment=mikbill_auto-{$addr_list}-OUT_country disabled=no \\\n" );
		array_push ( $rules, "	new-packet-mark={$addr_list}-OUT_country passthrough=no src-address-list={$addr_list} dst-address-list=country\n" );
		/* Маркировка исходящего трафика */
		array_push ( $rules, "add action=mark-packet chain=postrouting comment=mikbill_auto-{$addr_list}-IN_country disabled=no \\\n" );
		array_push ( $rules, "	new-packet-mark={$addr_list}-IN_country passthrough=no dst-address-list={$addr_list} src-address-list=country\n" );
		
		return $rules;
	}
	
	public function create_queque_type($addr_list, $country, $interval, $pcq_in, $pcq_out, $burst_in, $burst_out, $threshold_in, $threshold_out, $time_in, $time_out)
	{
		$rules=array();
		
		if($time_in == "0")
			$time_in = 1;
			
		if($time_out == "0")
			$time_out = 1;
		
		if($burst_in == "")
			$burst_in=0;
		
		if($burst_out == "")
			$burst_out=0;
		
		if($threshold_in == "")
			$threshold_in =0;
		
		if($threshold_out == "")
			$threshold_out =0;
			
		if($threshold_in>$burst_in)
			$threshold_in=$burst_in;
			
		if($threshold_out>$burst_out)
			$threshold_out=$burst_out;
		
		array_push ( $rules, "/queue type\n" );
		/* Настройка скорости Upload */
		array_push ( $rules, "add kind=pcq name=mikbill_auto-{$addr_list}-IN{$interval}{$country} \\\n" );
		array_push ( $rules, "	pcq-limit=50 pcq-rate={$pcq_in}k pcq-total-limit=375 \\\n" );
		array_push ( $rules, "	pcq-burst-rate={$burst_in}k pcq-burst-threshold={$threshold_in}k pcq-burst-time={$time_in} \\\n" );
		array_push ( $rules, "	pcq-classifier=dst-address pcq-dst-address-mask=32 pcq-dst-address6-mask=64 pcq-src-address-mask=32 pcq-src-address6-mask=64\n" );
		/* Настройка скорости Download */
		array_push ( $rules, "add kind=pcq name=mikbill_auto-{$addr_list}-OUT{$interval}{$country} \\\n" );
		array_push ( $rules, "	pcq-limit=50 pcq-rate={$pcq_out}k pcq-total-limit=375 \\\n" );
		array_push ( $rules, "	pcq-burst-rate={$burst_out}k pcq-burst-threshold={$threshold_out}k pcq-burst-time={$time_out} \\\n" );
		array_push ( $rules, "	pcq-classifier=src-address pcq-dst-address-mask=32 pcq-dst-address6-mask=64 pcq-src-address-mask=32 pcq-src-address6-mask=64\n" );
	
		return $rules;
	}
	
	public function create_queque_tree()
	{
		$rules=array();
		//TODO: выяснить зачем создавали Queue Tree 
	}
	
	public function create_queque_simple($addr_list, $country, $interval, $start, $stop, $priority)
	{
		$rules=array();
		
		if($priority == 0)
			$priority = 1;
		
		switch($this->mk_ver)
		{
			case 1:
			{
				array_push ( $rules, "/queue simple\n" );
				array_push ( $rules, "add place-before=0 burst-limit=0/0 burst-threshold=0/0 burst-time=0s/0s comment=mikbill_auto-{$addr_list}{$interval}{$country} \\\n" );
				array_push ( $rules, "    disabled=no  limit-at=0/0 max-limit=0/0 name=mikbill_auto-{$addr_list}{$interval}{$country} \\\n" );
				array_push ( $rules, "    packet-marks={$addr_list}-OUT{$country},{$addr_list}-IN{$country} priority={$priority} parent=none interface=all \\\n" );
				array_push ( $rules, "    queue=mikbill_auto-{$addr_list}-OUT{$interval}{$country}/mikbill_auto-{$addr_list}-IN{$interval}{$country} \\\n" );
				array_push ( $rules, "    time={$start}-{$stop},sun,mon,tue,wed,thu,fri,sat total-queue=default-small target-addresses=0.0.0.0/0 \n" );  
				break;
			}
			
			case 2:
			{
				array_push ( $rules, "/queue simple\n" );
				array_push ( $rules, "add place-before=0 burst-limit=0/0 burst-threshold=0/0 burst-time=0s/0s comment=mikbill_auto-{$addr_list}{$interval}{$country} \\\n" );
				array_push ( $rules, "    disabled=no  limit-at=0/0 max-limit=0/0 name=mikbill_auto-{$addr_list}{$interval}{$country} \\\n" );
				array_push ( $rules, "    packet-marks={$addr_list}-OUT{$country},{$addr_list}-IN{$country} priority={$priority}/{$priority} parent=none \\\n" );
				array_push ( $rules, "    queue=mikbill_auto-{$addr_list}-OUT{$interval}{$country}/mikbill_auto-{$addr_list}-IN{$interval}{$country} \\\n" );
				array_push ( $rules, "    time={$start}-{$stop},sun,mon,tue,wed,thu,fri,sat total-queue=default-small \\\n" );
				array_push ( $rules, "    target=0.0.0.0/0 \n" );
				break;
			}
			
			default:
				break;
		}
		
		return $rules;
	}
}
?>