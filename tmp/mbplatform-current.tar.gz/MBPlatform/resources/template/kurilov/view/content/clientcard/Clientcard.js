/**
 * Created by noname on 10.01.2018.
 */
Ext.define('Admin.view.content.clientcard.Clientcard', {
    extend: 'Admin.view.widget.form.clientcard.Clientcard',

    requires: [
        'Admin.view.content.clientcard.ClientcardModel',
        'Admin.view.content.clientcard.ClientcardController'
    ],

    xtype: 'contentclientcard',

    viewModel: {
        type: 'contentclientcard'
    },

    layout: 'fit',

    controller: 'contentclientcard',

    reference: 'contentclientcard',

    listeners: {
        afterRender: 'onLoad',
        save: 'onSave',
        reload: 'onReload'
    },

    bodyPadding: 0,

    items: [
        {
            xtype: 'button',
            text: 'test'
        }
    ]

});