Ext.define("Ext.locale.it.data.validator.Exclusion", {
    override: "Ext.data.validator.Exclusion",

    message: "E' un valore che \u00E8 stato escluso"
});
