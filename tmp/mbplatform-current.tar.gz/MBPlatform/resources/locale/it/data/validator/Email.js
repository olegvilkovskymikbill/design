Ext.define("Ext.locale.it.data.validator.Email", {
    override: "Ext.data.validator.Email",

    message: "Non \u00E8 un indirizzo email valido"
});
