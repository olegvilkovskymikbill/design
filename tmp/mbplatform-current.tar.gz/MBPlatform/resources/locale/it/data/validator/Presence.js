Ext.define("Ext.locale.it.data.validator.Presence", {
    override: "Ext.data.validator.Presence",

    message: "Obbligatorio" 
});
