Ext.define("Ext.locale.it.data.validator.Bound", {
    override: "Ext.data.validator.Bound",

    emptyMessage: "Obbligatorio"
});
