Ext.define("Ext.locale.it.picker.Time", {
    override: "Ext.picker.Time",

    format: "H:i"
});
