Ext.define("Ext.locale.it.form.CheckboxGroup", {
    override: "Ext.form.CheckboxGroup",

    blankText: "Selezionare almeno un elemento nel gruppo"
});
