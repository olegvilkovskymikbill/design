Ext.define("Ext.locale.it.form.FieldSet", {
    override: "Ext.form.FieldSet",

    descriptionText: "{0} Gruppo", 
    expandText: "Espandi il Gruppo" 
});
