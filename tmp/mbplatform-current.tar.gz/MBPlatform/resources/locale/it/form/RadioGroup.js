Ext.define("Ext.locale.it.form.RadioGroup", {
    override: "Ext.form.RadioGroup",

    blankText: "Selezionare un elemento nel gruppo"
});
