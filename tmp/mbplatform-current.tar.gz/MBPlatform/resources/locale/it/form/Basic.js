Ext.define("Ext.locale.it.form.Basic", {
    override: "Ext.form.Basic",

    waitTitle: "Attendere..."
});
