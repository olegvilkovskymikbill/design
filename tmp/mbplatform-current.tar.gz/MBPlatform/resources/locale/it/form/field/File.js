Ext.define("Ext.locale.it.form.field.File", {
    override: "Ext.form.field.File",

    buttonText: 'Scegli...'
});
