Ext.define("Ext.locale.it.form.field.Text", {
    override: "Ext.form.field.Text",

    minLengthText: "La lunghezza minima \u00E8 {0}",
    maxLengthText: "La lunghezza massima \u00E8 {0}",
    blankText: "Campo obbligatorio"
});
