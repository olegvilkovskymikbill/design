Ext.define("Ext.locale.it.form.field.Base", {
    override: "Ext.form.field.Base",

    invalidText: "Valore non valido" 
});
