Ext.define("Ext.locale.it.form.field.Number", {
    override: "Ext.form.field.Number",

    minText: "Il valore minimo \u00E8 {0}", 
    maxText: "Il valore massimo \u00E8 {0}", 
    nanText: "{0} non \u00E8 un valore numerico valido",
    negativeText: "Il valore non pu\u00F2 essere negativo"
});
