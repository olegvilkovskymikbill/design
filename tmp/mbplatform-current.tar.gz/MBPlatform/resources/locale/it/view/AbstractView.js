Ext.define("Ext.locale.it.view.AbstractView", {
    override: "Ext.view.AbstractView",

    loadingText: "Caricamento..."
});
