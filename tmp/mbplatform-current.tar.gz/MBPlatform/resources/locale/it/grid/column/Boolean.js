Ext.define("Ext.locale.it.grid.column.Boolean", {
    override: "Ext.grid.column.Boolean",

    trueText: "vero",
    falseText: "falso"
});
