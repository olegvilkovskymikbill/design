Ext.define("Ext.locale.it.grid.feature.Grouping", {
    override: "Ext.grid.feature.Grouping",

    groupByText: 'Raggruppa per questo campo',
    showGroupsText: 'Mostra nei gruppi', 
    expandTip: 'Clicca per espandere. Con il tasto CTRL riduce tutti gli altri',
    collapseTip: 'Clicca per ridurre. Con il tasto CTRL espande tutti gli altri'
});
