Ext.define("Ext.locale.it.grid.filters.filter.String", {
    override: "Ext.grid.filters.filter.String",

    emptyText: 'Inserisci il Valore...'
});
