Ext.define("Ext.locale.it.grid.filters.Filters", {
    override: "Ext.grid.filters.Filters",

    menuFilterText: 'Filtri' 
});
