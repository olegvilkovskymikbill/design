Ext.define("Ext.locale.it.grid.filters.filter.Boolean", {
    override: "Ext.grid.filters.filter.Boolean",

    yesText: 'Si',
    noText: 'No'
});
