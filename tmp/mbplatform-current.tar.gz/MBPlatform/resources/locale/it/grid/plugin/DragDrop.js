Ext.define("Ext.locale.it.grid.plugin.DragDrop", {
    override: "Ext.grid.plugin.DragDrop",

    dragText: "{0} Righe selezionate"
});
