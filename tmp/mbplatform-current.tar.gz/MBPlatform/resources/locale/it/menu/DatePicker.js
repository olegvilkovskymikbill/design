Ext.define("Ext.locale.it.menu.DatePicker", {
    override: 'Ext.menu.DatePicker',

    ariaLabel: 'Scegli Data'
});
