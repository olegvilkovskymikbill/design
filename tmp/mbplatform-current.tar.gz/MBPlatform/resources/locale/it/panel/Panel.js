Ext.define("Ext.locale.it.panel.Panel", {
    override: 'Ext.panel.Panel',

    closeToolText: 'Chiudi', 
    collapseToolText: 'Riduci',
    expandToolText: 'Espandi' 
});
