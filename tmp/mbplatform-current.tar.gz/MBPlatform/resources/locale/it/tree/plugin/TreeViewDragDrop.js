Ext.define("Ext.locale.it.tree.plugin.TreeViewDragDrop", {
    override: 'Ext.tree.plugin.TreeViewDragDrop',

    dragText: '{0} nodi selezionati' // '{0} selected node{1}',
});
