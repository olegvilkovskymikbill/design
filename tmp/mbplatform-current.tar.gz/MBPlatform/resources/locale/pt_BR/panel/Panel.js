/**
 * Portuguese/Brazil Translation by Guilherme Portela
 * 07 March 2016
 */
Ext.define("Ext.locale.pt_BR.panel.Panel", {
    override: "Ext.panel.Panel",
    closeToolText: "Fechar painel",
    collapseToolText: "Recolher painel",
    expandToolText: "Expandir painel"   
});