Ext.define('Ext.locale.pt_BR.grid.filters.filter.Boolean', {
    override: 'Ext.grid.filters.filter.Boolean',
    yesText: 'Sim',
    noText : 'Não'
});
