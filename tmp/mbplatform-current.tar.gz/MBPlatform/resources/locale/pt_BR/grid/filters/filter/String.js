Ext.define('Ext.locale.pt_BR.grid.filters.filter.String', {
    override: 'Ext.grid.filters.filter.String',
    emptyText: 'Digite o texto de filtro...'
});