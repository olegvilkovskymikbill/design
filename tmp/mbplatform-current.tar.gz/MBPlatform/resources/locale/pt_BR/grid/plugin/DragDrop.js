Ext.define("Ext.locale.pt_BR.grid.plugin.DragDrop", {
    override: "Ext.grid.plugin.DragDrop",
    dragText: "{0} linha(s) selecionada(s)"
});