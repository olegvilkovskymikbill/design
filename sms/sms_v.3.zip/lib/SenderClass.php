<?php

/**
 * Created by PhpStorm.
 * User: Maxim
 * Date: 18.05.2016
 * Time: 11:16
 */
class SenderClass extends Model
{

    private $_gatewayType = null;
    private $_sender = 'ISP';
    private $_login = '';
    private $_pass = '';
    private $_apiKey = '';

    public function __construct()
    {
        $mikbillClass = new MikBillClass();
        $configSMS = $mikbillClass->getSystemOptions("`key` LIKE 'sms_gateway_%'");

        if (isset($configSMS['sms_gateway_login']) and $configSMS['sms_gateway_login'] != '') {
            $this->_login = $configSMS['sms_gateway_login'];
        }

        if (isset($configSMS['sms_gateway_password']) and $configSMS['sms_gateway_password'] != '') {
            $this->_pass = $configSMS['sms_gateway_password'];
        }

        if (isset($configSMS['sms_gateway_apikey']) and $configSMS['sms_gateway_apikey'] != '') {
            $this->_apiKey = $configSMS['sms_gateway_apikey'];
        }

        if (isset($configSMS['sms_gateway_sender'])) {
            $this->_sender = $configSMS['sms_gateway_sender'];
        }

        if (isset($configSMS['sms_gateway_type']) and is_numeric($configSMS['sms_gateway_type'])) {
            $this->_gatewayType = $configSMS['sms_gateway_type'];
        }

    }
    public function sendingSMS($user, $templID, $comment = 'unknown', $param = array())
    {
        if (!empty($user['sms_tel'])) {


            if (ConfigClass::$_replace_phone == 1) {

                // Если Рус Шлюз
                if (in_array( $this->_gatewayType, array(
                    2,
                    5
                ))) {
                    $phone = SystemClass::replaceNumberRUS($user['sms_tel']);
                } else {
                    $phone = SystemClass::replaceNumberUKR($user['sms_tel']);
                }
            } else {
                $phone = $user['sms_tel'];
            }

            $templSmsClass = new TemplateSMS();

            $templText = $templSmsClass->getTemplate($templID);
            $textSMS = $templSmsClass->parserText($templText, $user, $param);

            $this->doSend($phone, $textSMS, $user);
        }
    }

    public function doSend($phone, $text, $user)
    {
        switch ($this->_gatewayType) {

            # SMS Ukraine
            case 1:
                $sms = new SmsUkraineClass($this->_login , $this->_pass);
                $sms->sendSMS($this->_sender, $phone, $text);
                break;

            # SMS Pilot
            case 2:
                $sms = new SmsPilotClass($this->_apiKey);
                $sms->sendSMS($this->_sender, $phone, $text);
                break;

            # SMS Fly
            case 3:
                $sms = new SmsFlyClass($this->_login , $this->_pass);
                $sms->sendSMS($this->_sender, $phone, $text);
                break;

            # SMS Beeline
            case 5:
                $sms = new SmsBeelineClass($this->_login , $this->_pass);
                $sms->sendSMS($this->_sender, $phone, $text);
                break;

            # SMS Turbo SMS
            case 6:
                $sms = new TurboSMSClass($this->_login , $this->_pass);
                $sms->sendSMS($this->_sender, $phone, $text);
                break;
        }

        if (ConfigClass::$_do_log == 1) {
            $this->doSMSLog($phone, $text, $user['uid'], $sms->_error);
        }

        if ($sms->_error != false) {
            return $sms->_error;
        } else {
            return $sms->_status;
        }
    }

    private function doSMSLog($phoneNumber, $message, $uid, $smsError)
    {
        $db = $this->getAdapter();

        $sms_type_id = 4;

        if ($smsError != false) {
            $error = 1;
            $errorText = iconv('utf-8', 'koi8-u', $smsError);
        } else {
            $error = 0;
            $errorText = '';
        }

        $this->setConnectionToUTF8();

        $db->query("INSERT INTO sms_logs (`uid`, `sms_phone`, `sms_text`, `sms_code`, `sms_error_text`, `sms_type_id`) VALUES (?i, ?s, ?s, ?i, ?s, ?i);",
            $uid, $phoneNumber, $message, $error, $errorText, $sms_type_id);

        $this->setConnectionToKoi8r();
    }
}