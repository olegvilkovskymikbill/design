<?php

/**
 * Created by PhpStorm.
 * User: Maxim
 * Date: 02.05.2016
 * Time: 0:50
 */
class DB
{
	private static $_db = null;
	private static $instance = null;

	private function __construct($opt)
	{
		# установим соединение с БД MikBiLL
		$opt['charset'] = 'koi8r';
		self::$_db = new SafeMySQL($opt);
	}

	public static function getInstance($opt = array())
	{
		if (self::$instance === null) {
			self::$instance = new self($opt);
		}

		return self::$_db;
	}

	public static function setAdapter($opt = array())
	{
		if (self::$instance === null) {
			self::$instance = new self($opt);
		}
	}
}