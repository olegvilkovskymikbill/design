<?php
/**
 * Created by PhpStorm.
 * User: Maxim
 * Date: 18.05.2016
 * Time: 12:46
 */

class DepositClass {

	public function proceedSendSms($uid, $templ)
	{
		$mikBillClass = new MikBillClass();
		$serviceClass = new ServiceClass();

		$user = $mikBillClass->getUserByUid($uid);
		$paymentAmount = $mikBillClass->getPaymnetAmount($uid);

		$param = array("pay_amount" => $paymentAmount);

		# Если было на самом деле пополнение и оно больше 1 копейки - отсылаем смс
		if(!empty($paymentAmount) AND $paymentAmount > 0.1){

			// Проверим включем ли функционал услуги
			if (ConfigClass::$_service_id != 0){

				// Ищем активную услугу у абонента в случае успех отправляем смс
				if($serviceClass->checkActiveService($user['uid'], ConfigClass::$_service_id)){
					$sendSMS = new SenderClass();
					$sendSMS->sendingSMS($user, $templ, 'Deposit', $param);
				}

			}else{
				$sendSMS = new SenderClass();
				$sendSMS->sendingSMS($user, $templ, 'Deposit', $param);
			}
		}
	}
}