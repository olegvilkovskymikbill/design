<?php
/**
 * Created by PhpStorm.
 * User: Maxim
 * Date: 06.11.2016
 * Time: 14:18
 */

class ServiceClass extends Model
{
    public function checkActiveService($uid, $serviceID)
    {
        $db= $this->getAdapter();

        $service = $db->getAll("SELECT services_logs.uid as uid , services_logs.serviceid as serviceid FROM services LEFT JOIN services_logs ON services.serviceid = services_logs.serviceid WHERE services_logs.date > NOW() + INTERVAL 10 MINUTE AND uid = ?i AND services_logs.serviceid = ?i ORDER BY services.tarifservice ", $uid, $serviceID);

        if(!empty($service)){
            return true;
        }else{
            return false;
        }
    }
}