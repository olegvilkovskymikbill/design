<?php
/**
 * Created by PhpStorm.
 * User: Maxim
 * Date: 17.05.2016
 * Time: 12:01
 */

include_once('./lib/autoload.php');

$opt = SystemClass::getConfig(ConfigClass::$_file_config);
DB::setAdapter($opt);

$smsClass = new SmsClass();
$smsClass->proceedRequest();