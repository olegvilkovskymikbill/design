<?php

/**
 * Created by PhpStorm.
 * User: Maxim
 * Date: 03.05.2016
 * Time: 23:15
 */
class Model
{
	public function getAdapter()
	{
		return DB::getInstance();
	}
}