<?php

/**
 * Created by PhpStorm.
 * User: Maxim
 * Date: 17.05.2016
 * Time: 18:30
 */
class LeftDayClass extends Model
{
	public function proceedSendSms($left_day, $templ)
	{
		$mikBillClass = new MikBillClass();
		$usersArray = $mikBillClass->getUserForLeftDayAll($left_day);

		$param = array("left_day" => $left_day);

		foreach ($usersArray as $user) {
			$sendSMS = new SenderClass();
			$sendSMS->sendingSMS($user, $templ, 'Left Day', $param);
		}
	}
}