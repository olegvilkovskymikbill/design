<?php
/**
 * Created by PhpStorm.
 * User: Maxim
 * Date: 17.05.2016
 * Time: 12:34
 */

class TemplateSMS {

	public function getTemplate($id)
	{
		switch($id){

			case 1:
				$text = 'Счет пополнен успешно. Ваш баланс %deposit% %currency%';
				break;

			case 2:
				$text = 'Уважаемый абонент (login %login%) счет пополнен. Ваш баланс %deposit% %currency%';
				break;

			case 3:
				$text = 'Ваш счет пополнен на сумму %pay_amount% %currency% Теперь ваш баланс составляет %deposit% %currency%';
				break;

			case 4:
				$text = 'Счет пополнен на %pay_amount% %currency% Ваш баланс составляет %deposit% %currency%';
				break;

			case 5:
				$text = 'Ув. абонент ( лиц счет №: %dogovor%). Ваш счет пополнен на %pay_amount% %currency% На вашем счете %deposit% %currency%';
				break;

			case 6:
				$text = 'Ваш счет пополнен на сумму %deposit% %currency%';
				break;

			case 7:
				$text = 'Уважаемый абонент. Услуга Интернет будет отключена через %left_day%-дня. Пополните свой счет.';
				break;

			case 8:
				$text = 'Уважаемый абонент. Услуга Интернет будет отключена через 1 день. Пополните свой счет.';
				break;

			case 9:
				$text = 'Ув.абонент (лиц счет №: %dogovor%). Услуга интернет будет отключена через %left_day%-дня. Пополните свой счет';
				break;

			case 10:
				$text = 'Срок Вашего тарифа кончается через сутки. На Вашем счету: %deposit% %currency%';
				break;

			case 11:
				$text = 'Уважаемый абонент. Услуга Кредит активирована.';
				break;

			default:
				$text = '';
		}

		return $text;
	}

	public function parserText($text, $user, $param = array())
	{
		# %left_day%
		if(!empty($param['left_day'])){
			$text = str_replace('%left_day%', $param['left_day'], $text);
		}

		# %pay_amount%
		if(!empty($param['pay_amount'])){
			$text = str_replace('%pay_amount%', $param['pay_amount'], $text);
		}

		# %uid%
		$text = str_replace('%uid%', $user['uid'], $text);

		# %fio
		$text = str_replace('%fio%', $user['fio'], $text);

		# %deposit%
		$text = str_replace('%deposit%', $user['deposit'], $text);

		# %credit%
		$text = str_replace('%credit%', $user['credit'], $text);

		# %login%
		$text = str_replace('%login%', $user['user'], $text);

		# %dogovor%
		$text = str_replace('%dogovor%', $user['numdogovor'], $text);

		# %company%
		$text = str_replace('%company%', ConfigClass::$_company_name, $text);

		# %currency%
		$text = str_replace('%currency%', ConfigClass::$_currency, $text);

		return $text;
	}
}