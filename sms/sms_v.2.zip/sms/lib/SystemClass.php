<?php

/**
 * Created by PhpStorm.
 * User: Maxim
 * Date: 06.05.2016
 * Time: 1:09
 */
class SystemClass
{
	public static function convertToUTF($inputArray)
	{
		$out = array();
		foreach ($inputArray AS $key => $row ) {

			if(is_array($row)){
				foreach ($row AS $field => $value) {
					$row[$field] = iconv('koi8-u', 'utf-8', $value);
				}
			}else{
				$row = iconv('koi8-u', 'utf-8', $row);
			}

			$out[$key] = $row;
		}

		return $out;
	}

	# Запись логов в файл
	public static function log_str($datalog, $filelog)
	{
		$nowdate = date("Y-m-d H:i:s");
		$open_file = fopen($filelog, 'a+');
		fwrite($open_file, $nowdate . ': ' . $datalog . "\r\n");
		fclose($open_file);
	}

	public static function getParams()
	{
		$params_input = array();

		if (!empty($_POST) AND is_array($_POST)) {
			foreach ($_POST as $k => $v) {
				$params_input[$k] = $v;
			}
		}
		if (!empty($_GET) AND is_array($_GET)) {
			foreach ($_GET as $k => $v) {
				$params_input[$k] = $v;
			}
		}

		return $params_input;
	}


	public static function getConfig($path)
	{

		//Проверяем есть ли файл конфигурации MB
		if (file_exists($path)) {
			$xml = simplexml_load_file($path);

			$CONF_MYSQL_HOST = (string) $xml->parameters->mysql->host;
			$CONF_MYSQL_USERNAME = (string) $xml->parameters->mysql->username;
			$CONF_MYSQL_PASSWORD = (string) $xml->parameters->mysql->password;
			$CONF_MYSQL_DBNAME = (string) $xml->parameters->mysql->dbname;

			$CONF_TIMEZONE = (string) $xml->parameters->timezone;
			date_default_timezone_set ( $CONF_TIMEZONE );

			$opt = array(
				'host' => $CONF_MYSQL_HOST,
				'user' => $CONF_MYSQL_USERNAME,
				'pass' => $CONF_MYSQL_PASSWORD,
				'db'   => $CONF_MYSQL_DBNAME,
			);

			return $opt;
		} else {
			die('Error read config file');
		}
	}

	public static function replaceNumberUKR($inputNumber)
	{
		$mobNumber = preg_replace("|[^\d\(\)-+]|", '', $inputNumber);
		$outNumber = $mobNumber;

		if (strlen($mobNumber) == 10) {
			$outNumber = '38' . $mobNumber;
		} elseif (strlen($mobNumber) == 11) {
			$outNumber = '3' . $mobNumber;
		}

		return $outNumber;
	}

	public static function replaceNumberRUS($inputNumber)
	{
		$mobNumber = preg_replace("|[^\d\(\)-+]|", '', $inputNumber);
		$outNumber = $mobNumber;

		if (strlen($mobNumber) == 10) {
			$outNumber = '7' . $mobNumber;
		}

		return $outNumber;
	}

}