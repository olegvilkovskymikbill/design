<?php

/**
 * Created by PhpStorm.
 * User: Maxim
 * Date: 18.05.2016
 * Time: 11:16
 */
class SenderClass
{

	public function sendingSMS($user, $templID, $comment = 'unknown', $param = array())
	{
		if (!empty($user['sms_tel'])) {

			if (ConfigClass::$_replace_phone == 1) {

				// Если Рус Шлюз
				if (in_array(ConfigClass::$_gateway, array(
					2,
					4
				))) {
					$phone = SystemClass::replaceNumberRUS($user['sms_tel']);
				} else {
					$phone = SystemClass::replaceNumberUKR($user['sms_tel']);
				}
			} else {
				$phone = $user['sms_tel'];
			}

			$templSmsClass = new TemplateSMS();

			$templText = $templSmsClass->getTemplate($templID);
			$textSMS = $templSmsClass->parserText($templText, $user, $param);

			$status_send = $this->doSend($phone, $textSMS);

			if (ConfigClass::$_do_log == 1) {
				$log_text = ('Send ' . $comment . ' Uid:' . $user['uid'] . '   Phohe:' . $user['sms_tel'] . '   Text:' . $textSMS . '  Response:' . $status_send);
				SystemClass::log_str($log_text, "sms_log.txt");
			}
		}
	}

	public function doSend($phone, $text)
	{
		$company = ConfigClass::$_company_name;

		switch (ConfigClass::$_gateway) {

			# SMS Ukraine
			case 1:
				$sms = new SmsUkraineClass(ConfigClass::$_sms_ukraine_login, ConfigClass::$_sms_ukraine_pass);
				$sms->sendSMS($company, $phone, $text);
				break;

			# SMS Pilot
			case 2:
				$sms = new SmsPilotClass(ConfigClass::$_pilot_apikey);
				$sms->sendSMS($company, $phone, $text);
				break;

			# SMS Fly
			case 3:
				$sms = new SmsFlyClass(ConfigClass::$_sms_fly_login, ConfigClass::$_sms_fly_pass);
				$sms->sendSMS($company, $phone, $text);
				break;

			# SMS Beeline
			case 4:
				$sms = new SmsBeelineClass(ConfigClass::$_sms_beeline_login, ConfigClass::$_sms_beeline_pass);
				$sms->sendSMS($company, $phone, $text);
				break;

			# SMS Turbo SMS
			case 5:
				$sms = new TurboSMSClass(ConfigClass::$_sms_turbo_sms_login, ConfigClass::$_sms_turbo_sms_pass);
				$sms->sendSMS($company, $phone, $text);
				break;
		}

		if ($sms->_error != false) {
			return $sms->_error;
		} else {
			return $sms->_status;
		}
	}
}