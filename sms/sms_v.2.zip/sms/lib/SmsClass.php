<?php
/**
 * Created by PhpStorm.
 * User: Maxim
 * Date: 17.05.2016
 * Time: 12:31
 */

class SmsClass extends Model {

	public function proceedRequest()
	{
		if ($_SERVER["argc"] > 1) {

			switch ($_SERVER["argv"][1]) {

				case "left_day":
					$this->SendLeftDay();
					break;

				case "deposit":
					$this->SendDeposit();
					break;

				case "credit":
					$this->SendCredit();
					break;
			}
		}
	}


	/**
	 * Отправка СМС за n-дней
	 *
	 * Параметры: left_day::кол-во_дней::шаблон
	 * Пример вызова: php send_sms.php left_day 3 7
	 *
	 */
	private function SendLeftDay(){

		if(ConfigClass::$_send_leftday_on == 1 AND intval($_SERVER["argv"][2]) >= 0 AND !empty($_SERVER["argv"][3])){
			$left_day = $_SERVER["argv"][2];
			$templ = $_SERVER["argv"][3];

			$leftDayClass = new LeftDayClass();
			$leftDayClass->proceedSendSms($left_day, $templ);
		}
	}

	/**
	 * Отправка при пополнении счета
	 *
	 * Параметры: deposit::uid::шаблон
	 */
	private function SendDeposit()
	{
		if( ConfigClass::$_send_deposit_on == 1 AND intval($_SERVER["argv"][2]) > 0 AND !empty($_SERVER["argv"][3])){

			$uid = intval($_SERVER["argv"][2]);
			$templ = $_SERVER["argv"][3];

			$depositClass = new DepositClass();
			$depositClass->proceedSendSms($uid, $templ);
		}
	}

	private function SendCredit()
	{
		if( ConfigClass::$_send_credit_on == 1 AND intval($_SERVER["argv"][2]) > 0 AND !empty($_SERVER["argv"][3])){

			$uid = intval($_SERVER["argv"][2]);
			$templ = $_SERVER["argv"][3];

			$depositClass = new CreditClass();
			$depositClass->proceedSendSms($uid, $templ);
		}
	}
}