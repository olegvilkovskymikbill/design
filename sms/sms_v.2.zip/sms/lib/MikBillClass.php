<?php

/**
 * Created by PhpStorm.
 * User: Maxim
 * Date: 17.05.2016
 * Time: 12:33
 */
class MikBillClass extends Model
{

	private $_column = 'uid,  user,  ROUND(deposit, 2) AS deposit, ROUND(credit, 2) AS credit, fio, numdogovor, sms_tel,  mob_tel,  phone';

	//  Packet Type
	//  0 - не снимать;
	//  1 - КД, если было подключение; +
	//  7 - ОКД (фикс.); +
	//  8 - обязательно каждый месяц;
	//  9 - обязательно каждый месяц, потратить сумму;
	//  10 - ОКД (пропорц.); +
	//  11 - обязательно каждый месяц, плавающая дата

	/**
	 * @param $left_day
	 *
	 * @return array
	 */
	public function getUserForLeftDayAll($left_day)
	{
		# Получаем пользователей с тарифами "КД, если было подключение" и "обязательно каждый день"
		$users_packet_type_1_7 = $this->getUserPacketType_1_7($left_day);

		#Получаем пользователей с тарифом "Обязательно каждый месяц"
		$users_packet_type_8 = $this->getUserPacketType_8($left_day);

		# Получаем пользователей с тарифом "каждый день пропорционально"
		$users_packet_type_10 = $this->getUserPacketType_10($left_day);

		# Получаем пользователей с тарифом "Обязательно каждый месяц, плавающая дата"
		$users_packet_type_11 = $this->getUserPacketType_11($left_day);

		$usersArray = array_merge($users_packet_type_1_7, $users_packet_type_8, $users_packet_type_10, $users_packet_type_11);

		return SystemClass::convertToUTF($usersArray);
	}


	/***
	 * 1 - КД, если было подключение; 7 - ОКД (фикс.);
	 *
	 * @param $leftDay
	 *
	 * @return array
	 */
	public function getUserPacketType_1_7($leftDay)
	{
		$db = $this->getAdapter();

		$day = intval($leftDay);
		$day2 = intval($leftDay) + 1;

		$result = $db->getAll("SELECT ?p FROM users LEFT JOIN packets ON users.gid = packets.gid WHERE ((deposit + credit) >= (packets.fixed_cost * ?i)) AND ((deposit + credit) < (packets.fixed_cost * ?i )) AND (packets.fixed = 1 OR packets.fixed = 7) AND users.blocked = 0 AND sms_tel IS NOT NULL AND sms_tel <> '' ", $this->_column, $day, $day2);

		return $result;
	}

	/**
	 * 8 - Обязательно каждый месяц
	 *
	 * @param $leftDay
	 *
	 * @return array
	 */
	public function getUserPacketType_8($leftDay)
	{
		$db = $this->getAdapter();

		$day = intval($leftDay);

		$result = $db->getAll("SELECT ?p FROM users, packets WHERE date_abonka = DAYOFMONTH( DATE_ADD(NOW( ), INTERVAL ?i DAY) ) AND users.gid = packets.gid AND packets.fixed = 8 AND deposit + credit < (packets.fixed_cost+(users.real_ip*packets.real_price)) AND users.blocked = 0 AND sms_tel IS NOT NULL AND sms_tel <> '' ", $this->_column, $day);

		return $result;
	}

	/**
	 * 10 - ОКД (пропорц.); +
	 *
	 * @param $leftDay
	 *
	 * @return array
	 */
	public function getUserPacketType_10($leftDay)
	{
		$db = $this->getAdapter();

		$day = intval($leftDay);
		$day2 = intval($leftDay) + 1;

		$result = $db->getAll("SELECT ?p FROM users LEFT JOIN packets ON users.gid = packets.gid WHERE ((deposit + credit) >= (packets.fixed_cost/DATE_FORMAT(LAST_DAY(NOW()), '%d') * ?i)) AND ((deposit + credit) < (packets.fixed_cost/DATE_FORMAT(LAST_DAY(NOW()), '%d') * ?i)) AND packets.fixed = 10 AND users.blocked = 0 AND sms_tel IS NOT NULL AND sms_tel <> '' ", $this->_column, $day, $day2);

		return $result;
	}


	/**
	 * 11 - плавающая дата
	 *
	 * @param $leftDay
	 *
	 * @return array
	 */
	public function getUserPacketType_11($leftDay)
	{
		$db = $this->getAdapter();

		$day = intval($leftDay);

		$result = $db->getAll("SELECT ?p FROM users u LEFT JOIN packets p ON u.gid = p.gid WHERE u.date_abonka = DATE_FORMAT(NOW() + INTERVAL ?i DAY, '%d') AND p.fixed = 11 AND u.blocked = 0 	AND (u.deposit + u.credit) < (p.fixed_cost + u.real_ip * p.real_price) * (1 - u.fixed_cost/100) AND sms_tel IS NOT NULL AND sms_tel <> '' ", $this->_column, $day);

		return $result;
	}

	/**
	 * Получить абонента по UID
	 *
	 * @param $uid
	 *
	 * @return array
	 */
	public function getUserByUid($uid)
	{
		$db = $this->getAdapter();

		$result = $db->getRow("SELECT ?p FROM users WHERE uid = ?i LIMIT 1;", $this->_column, $uid);

		return SystemClass::convertToUTF($result);
	}

	/**
	 * Получить суммау последнего платежа по UID
	 *
	 * @param $uid
	 *
	 * @return mixed
	 */
	public function getPaymnetAmount($uid)
	{
		$amount_pay = $this->getPayment($uid);
		$amount_card = $this->getLastPaymentCard($uid);

		return ($amount_pay + $amount_card);
	}

	/**
	 * Получить сумму платежа по уид
	 *
	 * @param $uid
	 *
	 * @return mixed
	 */
	public function getPayment($uid)
	{
		$db = $this->getAdapter();

		$result = $db->getOne("SELECT ROUND(summa, 2) AS summa FROM bugh_plategi_stat WHERE uid =?i AND date > NOW() - INTERVAL 15 SECOND AND bughtypeid  NOT IN (1, 2, 6, 7, 9, 10, 15, 16, 17, 18, 20, 21, 22, 23, 24, 25, 26, 27, 29, 30, 32, 33, 34, 35, 36, 42, 43, 46, 48, 49, 50, 51, 64, 65, 72, 73, 74, 75) ORDER BY plategid DESC LIMIT 1;", $uid);

		return $result;
	}

	/**
	 * Получить последний платеж карточкой по Uid
	 * @param $uid
	 *
	 * @return FALSE|string
	 */
	public function getLastPaymentCard($uid)
	{
		$db = $this->getAdapter();

		$result = $db->getOne("SELECT ROUND(summa, 2) AS summa FROM bugh_cards_log WHERE uid = ?i AND date > NOW() - INTERVAL 15 SECOND LIMIT 1;", $uid);

		return $result;
	}

	public function getPaymentCredit($uid)
	{
		$db = $this->getAdapter();

		$result = $db->getOne("SELECT uid FROM bugh_plategi_stat WHERE uid =?i AND date > NOW() - INTERVAL 15 SECOND AND bughtypeid = 18 ORDER BY plategid DESC LIMIT 1;", $uid);

		return $result;
	}
}