<?php
/**
 * Created by PhpStorm.
 * User: Maxim
 * Date: 18.05.2016
 * Time: 14:09
 */

class CreditClass {

	public function proceedSendSms($uid, $templ)
	{
		$mikBillClass = new MikBillClass();

		$user = $mikBillClass->getUserByUid($uid);
		$paymentCredit = $mikBillClass->getPaymentCredit($uid);

		# Если было на самом деле взятие Кредита - отсылаем смс
		if(!empty($paymentCredit)){
			$sendSMS = new SenderClass();
			$sendSMS->sendingSMS($user, $templ, 'Credit');
		}
	}
}