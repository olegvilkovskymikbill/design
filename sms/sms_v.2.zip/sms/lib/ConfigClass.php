<?php
/**
 * Created by PhpStorm.
 * User: Maxim
 * Date: 17.05.2016
 * Time: 12:38
 */

class ConfigClass {

	# Путь к конфигу для БД
	public static $_file_config = '../../app/etc/config.xml';

	# Логирование отправки SMS
	public static $_do_log = 1;

	# Исправлять номер под формат страны
	public static $_replace_phone = 1;


	# Название компании
	public static $_company_name = 'ForBiLL';

	# Валюта в смс
	public static $_currency = 'грн.';

	# SMS Gateway
	# 1. SMS Ukraine
	# 2. SMS Pilot
	# 3. SMS Fly
	# 4. SMS Beeline
	# 5. Turbo SMS (SOAP)
	public static $_gateway = 1;

	# SMS Pilot (http://www.smspilot.ru/)
	public static $_pilot_apikey = 'xxxxxxxx';

	# SMS Ukraine (http://smsukraine.com.ua/)
	public static $_sms_ukraine_login = 'xxxxxxxx';
	public static $_sms_ukraine_pass = 'xxxxxxxx';

	# SMS Fly (https://sms-fly.com/)
	public static $_sms_fly_login = 'xxxxxxxx';
	public static $_sms_fly_pass = 'xxxxxxxx';

	# SMS Beeline (http://beeline.amega-inform.ru/)
	public static $_sms_beeline_login = 'xxxxxxxx';
	public static $_sms_beeline_pass = 'xxxxxxxx';

	# Turbo SMS (https://turbosms.ua)
	public static $_sms_turbo_sms_login = 'xxxxxxxx';
	public static $_sms_turbo_sms_pass = 'xxxxxxxx';

	#---------------------------------------------------------
	# ПРИ ПОПОЛНЕНИИ СЧЕТА

	# Отправлять СМС при пополнении баланса (1= ВКЛ; 0 = ВЫКЛ)
	public static $_send_deposit_on = 1;


	#---------------------------------------------------------
	# ОСТАТОК ДНЕЙ УСЛУГИ

	# Отправлять за n-дней до отключения (1= ВКЛ; 0 = ВЫКЛ)
	public static $_send_leftday_on = 1;


	#---------------------------------------------------------
	# ПРИ ПОПОЛНЕНИИ КРЕДИТА

	# Отправлять СМС при взятии кредита (1= ВКЛ; 0 = ВЫКЛ)
	public static $_send_credit_on = 0;

}