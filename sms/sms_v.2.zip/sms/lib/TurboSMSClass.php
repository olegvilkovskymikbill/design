<?php

/**
 * Created by PhpStorm.
 * User: Maxim
 * Date: 23.05.2016
 * Time: 23:47
 */
class TurboSMSClass
{
	protected $_server = 'http://turbosms.in.ua/api/wsdl.html';

	private $login = false;          // Логин
	private $pass = false;           // Пароль

	public $_error = false;          // Ошибки
	public $_status;          // Статус


	public function __construct($apiLogin = false, $apiPass = false)
	{
		if ($apiLogin) {
			$this->login = $apiLogin;
		}

		if ($apiPass) {
			$this->pass = $apiPass;
		}
	}

	// send sms  https://turbosms.ua/
	public function sendSMS($from = false, $to = false, $text = false)
	{
		try {

			// Данные авторизации
			$auth = array(
				'login'    => $this->login,
				'password' => $this->pass
			);

			$sms = array(
				'sender'      => $from,
				'destination' => $to,
				'text'        => $text
			);

			// Подключаемся к серверу
			$client = new SoapClient($this->_server);

			// Авторизируемся на сервере
			$result = $client->Auth($auth);

			if (isset($result->AuthResult) AND $result->AuthResult == "Вы успешно авторизировались") {

				$result = $client->SendSMS($sms);

				if (isset($result->SendSMSResult->ResultArray[1]) AND $result->SendSMSResult->ResultArray[0] == "Сообщения успешно отправлены") {
					$this->_status = $result->SendSMSResult->ResultArray[1];

				} elseif (isset($result->SendSMSResult->ResultArray[1]) AND !empty($result->SendSMSResult->ResultArray[1])) {
					$this->_error = $result->SendSMSResult->ResultArray[1];

				} elseif (isset($result->SendSMSResult->ResultArray[1]) AND empty($result->SendSMSResult->ResultArray[1])) {
					$this->_error = $result->SendSMSResult->ResultArray[0];
				}else{
					$this->_error = $result->SendSMSResult->ResultArray;
				}
			} else {
				$this->_error = $result->AuthResult;
			}
		} catch (Exception $e) {
			echo 'Ошибка: ' . $e->getMessage() . PHP_EOL;
		}
	}
}