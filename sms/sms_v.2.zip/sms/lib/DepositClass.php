<?php
/**
 * Created by PhpStorm.
 * User: Maxim
 * Date: 18.05.2016
 * Time: 12:46
 */

class DepositClass {

	public function proceedSendSms($uid, $templ)
	{
		$mikBillClass = new MikBillClass();

		$user = $mikBillClass->getUserByUid($uid);
		$paymentAmount = $mikBillClass->getPaymnetAmount($uid);

		$param = array("pay_amount" => $paymentAmount);

		# Если было на самом деле пополнение и оно больше 1 копейки - отсылаем смс
		if(!empty($paymentAmount) AND $paymentAmount > 0.1){
			$sendSMS = new SenderClass();
			$sendSMS->sendingSMS($user, $templ, 'Deposit', $param);
		}
	}
}