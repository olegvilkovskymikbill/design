<?php
/**
 * Created by PhpStorm.
 * User: Maxim
 * Date: 03.05.2016
 * Time: 23:59
 */

function __autoload($className)
{
	$dir = './lib/';

	$classFullPath = $dir . $className . '.php';
	if (file_exists($classFullPath) AND is_readable($classFullPath)) {
		include_once($classFullPath);
	} else {
		echo "Problem while including class " . $className;
	}
}