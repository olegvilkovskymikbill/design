<?php

/**
 * Created by PhpStorm.
 * User: Maxim
 * Date: 03.05.2016
 * Time: 23:15
 */
class Model
{
	public function getAdapter()
	{
		return DB::getInstance();
	}

	public function setConnectionToKoi8r()
	{
		$db = $this->getAdapter();

		$query = "SET `character_set_client` = 'koi8r';";
		$db->query($query);
		$query = "CALL connect_switch_to_KOI8();";
		$db->query($query);
	}

	public function setConnectionToUTF8()
	{
		$db = $this->getAdapter();

		$query = "SET `character_set_client` = 'utf8';";
		$db->query($query);
		$query = "CALL connect_switch_to_UTF8();";
		$db->query($query);
	}

}