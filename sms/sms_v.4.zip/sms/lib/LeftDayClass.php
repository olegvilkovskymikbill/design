<?php

/**
 * Created by PhpStorm.
 * User: Maxim
 * Date: 17.05.2016
 * Time: 18:30
 */
class LeftDayClass extends Model
{
	public function proceedSendSms($left_day, $templ)
	{
		$serviceClass = new ServiceClass();
		$mikBillClass = new MikBillClass();
		$usersArray = $mikBillClass->getUserForLeftDayAll($left_day);


		$param = array("left_day" => $left_day);

		foreach ($usersArray as $user) {

			// Проверим включем ли функционал услуги
			if (ConfigClass::$_service_id != 0){

				// Ищем активную услугу у абонента в случае успех отправляем смс
				if($serviceClass->checkActiveService($user['uid'], ConfigClass::$_service_id)){
					$sendSMS = new SenderClass();
					$sendSMS->sendingSMS($user, $templ, 'Left Day', $param);
				}

			}else{
				$sendSMS = new SenderClass();
				$sendSMS->sendingSMS($user, $templ, 'Left Day', $param);
			}


		}
	}
}