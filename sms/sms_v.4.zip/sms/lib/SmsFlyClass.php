<?php
/**
 * Created by PhpStorm.
 * User: Maxim
 * Date: 18.05.2016
 * Time: 12:26
 */


/* SMS Fly.Class API/PHP
 * https://sms-fly.com/
 */

class SmsFlyClass
{
	public $api = 'http://sms-fly.com/api/api.php';
	public $charset = 'UTF-8';
	public $login;          // Логин
	public $pass;           // Пароль
	public $_error;          // Ошибки
	public $_status;          // Статус
	public $from = false;   // отправитель
	public $start_time = 'AUTO';// время начала отправки сообщения
	public $end_time = 'AUTO';  // время окончания отправки сообщения
	public $lifetime = 24;  // срок жизни сообщения(й) в часах
	public $rate = 120;     // скорость отправки сообщения
	public $description;    // описание рассылки (отображается в веб интерфейсе).
	public $source;         // отправитель
	public $text;           // текст смс-сообщения
	public $recipient;      // номер получателя в международном формате без разделителей

	public function __construct($apiLogin = false, $apiPass = false, $charset = false, $from = false)
	{

		if ($apiLogin) {
			$this->login = $apiLogin;
		}

		if ($apiPass) {
			$this->pass = $apiPass;
		}

		if ($charset) {
			$this->charset = $charset;
		}

		if ($from) {
			$this->from = $from;
		}
	}

	// send sms via sms-fly.com
	public function sendSMS($from = false, $recipient = false, $text = false)
	{
		if ($recipient) {
			$this->recipient = $recipient;
		}

		if ($text) {
			$this->text = $text;
		}

		if ($from) {
			$this->from = $from;
		}

		$this->_error = false;

		if ($this->charset != 'UTF-8') {
			$this->text = mb_convert_encoding($this->text, 'utf-8', $this->charset);
		}

		$dataXML = $this->buildXML();

		$result = $this->httpPost($this->api, $this->login, $this->pass, $dataXML);

		if ($result) {

			if (strpos($result, 'code="ACCEPT"') !== false) {
				$begin = intval(strpos($result, 'campaignID="')) + intval(strlen('campaignID="'));
				$this->_status = substr($result, $begin, intval(strpos($result, '" date="')) - $begin);
			} elseif (strpos($result, 'code="XMLERROR"') !== false) {
				$this->_error = 'XMLERROR';
			} elseif (strpos($result, 'code="ERRPHONES"') !== false) {
				$this->_error = 'ERRPHONES';
			} elseif (strpos($result, 'code="ERRSTARTTIME"') !== false) {
				$this->_error = 'ERRSTARTTIME';
			} elseif (strpos($result, 'code="ERRENDTIME"') !== false) {
				$this->_error = 'ERRENDTIME';
			} elseif (strpos($result, 'code="ERRLIFETIME"') !== false) {
				$this->_error = 'ERRLIFETIME';
			} elseif (strpos($result, 'code="ERRSPEED"') !== false) {
				$this->_error = 'ERRSPEED';
			} elseif (strpos($result, 'code="ERRALFANAME"') !== false) {
				$this->_error = 'ERRALFANAME';
			} elseif (strpos($result, 'code="ERRTEXT"') !== false) {
				$this->_error = 'ERRTEXT';
			} elseif (strpos($result, 'code="INSUFFICIENTFUNDS"') !== false) {
				$this->_error = 'INSUFFICIENTFUNDS';
			} elseif (strpos($result, 'code="ERRALFANAME"') !== false) {
				$this->_error = 'ERRALFANAME';
			} else {
				$this->_error = $result;
			}
		} else {
			$this->_error = 'CONNECTION ERROR';
		}
	}

	public function buildXML()
	{
		$start_time = $this->start_time;
		$end_time = $this->end_time;
		$lifetime = $this->lifetime;
		$rate = $this->rate;
		$description = $this->description;
		$source = $this->from;
		$text = $this->text;
		$recipient = $this->recipient;

		$xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n";
		$xml .= "<request>";
		$xml .= "<operation>SENDSMS</operation>";
		$xml .= '		<message start_time="' . $start_time . '" end_time="' . $end_time . '" lifetime="' . $lifetime . '" rate="' . $rate . '" desc="' . $description . '" source="' . $source . '">' . "\n";
		$xml .= "		<body>" . $text . "</body>";
		$xml .= "		<recipient>" . $recipient . "</recipient>";
		$xml .= "</message>";
		$xml .= "</request>";

		return $xml;
	}


	public function httpPost($url, $user, $password, $dataXML)
	{
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_USERPWD, $user . ':' . $password);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array(
			"Content-Type: text/xml",
			"Accept: text/xml"
		));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $dataXML);
		$response = curl_exec($ch);
		curl_close($ch);

		if ($response <> '') {
			return $response;
		} else {
			return false;
		}
	}
}
