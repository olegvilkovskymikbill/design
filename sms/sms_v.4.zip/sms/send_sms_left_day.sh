#!/bin/bash

OS=`uname`
PHP=`which php`

if [ "$OS" == "Linux" ]; then
#for linux
cd /var/www/mikbill/admin/res/sms/
else
#for BSD
cd /usr/local/www/mikbill/admin/res/sms/
fi

$PHP ./send_sms.php left_day 3 7
