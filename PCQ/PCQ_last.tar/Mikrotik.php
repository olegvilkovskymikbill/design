<?php

class Mikrotik
{
	
	private $network_list = "10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16";

	private $mk_id;
	private $mk_ip;
	private $mk_user;
	private $mk_pass;
	private $mk_ver;
	private $mk_iface;
	 
	private $ssh = 0;
	private $ftp = 0;
	private $enabled = false;
	
	public function add_mikrotik($id, $ip, $user, $pass, $iface, $ver)
	{
		$this->mk_id 	= $id;
		$this->mk_ip 	= $ip;
		$this->mk_user 	= $user;
		$this->mk_pass 	= $pass;
		$this->mk_iface = $iface;
		$this->mk_ver	= $ver;
	}
	
	public function get_id()
	{
		return $this->mk_id;
	}
	
	public function get_ip()
	{
		return $this->mk_ip;
	}
	
	public function get_user()
	{
		return $this->mk_user;
	}
	
	public function get_pass()
	{
		return $this->mk_pass;
	}
	
	public function get_iface()
	{
		return $this->mk_iface;
	}
	
	public function get_ver()
	{
		return $this->mk_ver;
	}
	
	public function enabled()
	{
		if($this->ssh == 1 && $this->ftp == 1)
			$this->enabled = true;
		return $this->enabled;
	}
	
	public function check_ssh()
	{
		if(!function_exists('fsockopen'))
		{ echo 'fsockopen не работает!'; return; }
		$tests = array(22 => $this->mk_ip);
		
		foreach($tests as $port => $server)
		{
			//Соединяемся
			$fp = @fsockopen($server,$port,$errno,$errstr,1);

			if($fp)
			{ 
				fclose($fp);
				$this->ssh = 1;
				return 1;
			}
			else
				return 0;
		}
	}
	
	public function check_ftp()
	{
		if(!function_exists('fsockopen'))
		{ echo 'fsockopen не работает!'; return; }
		$tests = array(21 => $this->mk_ip);
		
		foreach($tests as $port => $server)
		{
			//Соединяемся
			$fp = @fsockopen($server,$port,$errno,$errstr,1);

			if($fp)
			{ 
				fclose($fp); 
				$this->ftp = 1;
				return 1;
			}
			else
				return 0;
		}
	}
	
	public function create_clear_old()
	{
		$rules=array();
		/* Удаляем старые записи */
		
		array_push($rules, "/system scheduler remove [find name ~\"mikbill_auto\"]\n");
		array_push($rules, "/ip firewall mangle remove [find comment~\"mikbill_auto\"]\n");
		array_push($rules, "/queue simple remove [find comment~\"mikbill_auto\"]\n");
		array_push($rules, "/queue simple remove [find where name~\"hs\"]\n");
		array_push($rules, "/queue tree remove [find name~\"mikbill_auto\"]\n");
		array_push($rules, "/queue type remove [find name~\"mikbill.\"]\n");
		
		return $rules;
	}
	
	public function create_mangle($addr_list)
	{
		$rules=array();
		
		array_push ( $rules, "/ip firewall mangle\n" );
		/* Маркировка входящего трафика */
		array_push ( $rules, "add action=mark-packet chain=prerouting comment=mikbill_auto-{$addr_list}-OUT disabled=no \\\n" );
		array_push ( $rules, "	new-packet-mark={$addr_list}-OUT passthrough=no src-address-list={$addr_list}\n" );
		/* Маркировка исходящего трафика */
		array_push ( $rules, "add action=mark-packet chain=postrouting comment=mikbill_auto-{$addr_list}-IN disabled=no \\\n" );
		array_push ( $rules, "	new-packet-mark={$addr_list}-IN passthrough=no dst-address-list={$addr_list}\n" );
		
		return $rules;
	}
	
	public function create_turbo_mangle($addr_list)
	{
		$rules=array();
		
		array_push ( $rules, "/ip firewall mangle\n" );
		/* Маркировка входящего трафика */
		array_push ( $rules, "add action=mark-packet chain=prerouting comment=mikbill_auto-{$addr_list}-OUT_turbo disabled=no \\\n" );
		array_push ( $rules, "	new-packet-mark={$addr_list}-OUT_turbo passthrough=no src-address-list={$addr_list}_turbo\n" );
		/* Маркировка исходящего трафика */
		array_push ( $rules, "add action=mark-packet chain=postrouting comment=mikbill_auto-{$addr_list}-IN_turbo disabled=no \\\n" );
		array_push ( $rules, "	new-packet-mark={$addr_list}-IN_turbo passthrough=no dst-address-list={$addr_list}_turbo\n" );
		
		return $rules;
	}
	
	public function create_turbo_country_mangle($addr_list)
	{
		$rules=array();
		
		array_push ( $rules, "/ip firewall mangle\n" );
		/* Маркировка входящего трафика */
		array_push ( $rules, "add action=mark-packet chain=prerouting comment=mikbill_auto-{$addr_list}-OUT_country_turbo disabled=no \\\n" );
		array_push ( $rules, "	new-packet-mark={$addr_list}-OUT_country passthrough=no src-address-list={$addr_list}_turbo dst-address-list=country\n" );
		/* Маркировка исходящего трафика */
		array_push ( $rules, "add action=mark-packet chain=postrouting comment=mikbill_auto-{$addr_list}-IN_country_turbo disabled=no \\\n" );
		array_push ( $rules, "	new-packet-mark={$addr_list}-IN_country passthrough=no dst-address-list={$addr_list}_turbo src-address-list=country\n" );
		
		return $rules;
	}
	
	public function create_country_mangle($addr_list)
	{
		$rules=array();
		
		array_push ( $rules, "/ip firewall mangle\n" );
		/* Маркировка входящего трафика */
		array_push ( $rules, "add action=mark-packet chain=prerouting comment=mikbill_auto-{$addr_list}-OUT_country disabled=no \\\n" );
		array_push ( $rules, "	new-packet-mark={$addr_list}-OUT_country passthrough=no src-address-list={$addr_list} dst-address-list=country\n" );
		/* Маркировка исходящего трафика */
		array_push ( $rules, "add action=mark-packet chain=postrouting comment=mikbill_auto-{$addr_list}-IN_country disabled=no \\\n" );
		array_push ( $rules, "	new-packet-mark={$addr_list}-IN_country passthrough=no dst-address-list={$addr_list} src-address-list=country\n" );
		
		return $rules;
	}
	
	public function create_queue_type($addr_list, $country, $interval, $pcq_in, $pcq_out, $burst_in, $burst_out, $threshold_in, $threshold_out, $time_in, $time_out)
	{
		$rules=array();
		
		if($time_in == "0")
			$time_in = 1;
			
		if($time_out == "0")
			$time_out = 1;
		
		if($burst_in == "")
			$burst_in=0;
		
		if($burst_out == "")
			$burst_out=0;
		
		if($threshold_in == "")
			$threshold_in =0;
		
		if($threshold_out == "")
			$threshold_out =0;
			
		if($threshold_in>$burst_in)
			$threshold_in=$burst_in;
			
		if($threshold_out>$burst_out)
			$threshold_out=$burst_out;
		
		array_push ( $rules, "/queue type\n" );
		/* Настройка скорости Upload */
		array_push ( $rules, "add kind=pcq name=mikbill_auto-{$addr_list}-IN{$interval}{$country} \\\n" );
		array_push ( $rules, "	pcq-limit=50 pcq-rate={$pcq_in}k pcq-total-limit=375 \\\n" );
		array_push ( $rules, "	pcq-burst-rate={$burst_in}k pcq-burst-threshold={$threshold_in}k pcq-burst-time={$time_in} \\\n" );
		array_push ( $rules, "	pcq-classifier=dst-address pcq-dst-address-mask=32 pcq-dst-address6-mask=64 pcq-src-address-mask=32 pcq-src-address6-mask=64\n" );
		/* Настройка скорости Download */
		array_push ( $rules, "add kind=pcq name=mikbill_auto-{$addr_list}-OUT{$interval}{$country} \\\n" );
		array_push ( $rules, "	pcq-limit=50 pcq-rate={$pcq_out}k pcq-total-limit=375 \\\n" );
		array_push ( $rules, "	pcq-burst-rate={$burst_out}k pcq-burst-threshold={$threshold_out}k pcq-burst-time={$time_out} \\\n" );
		array_push ( $rules, "	pcq-classifier=src-address pcq-dst-address-mask=32 pcq-dst-address6-mask=64 pcq-src-address-mask=32 pcq-src-address6-mask=64\n" );
	
		return $rules;
	}
	
	public function create_queue_tree()
	{
		$rules=array();
		
		switch($this->mk_ver)
		{
			//5.x
			case 1:
			{
				array_push($rules, "/queue tree\n");
				array_push($rules, "add name=mikbill_auto_global parent=global-out priority=1 queue=default \n");	
				break;
			}
			//6.x
			case 2:
			{
				array_push($rules, "/queue tree\n");
				array_push($rules, "add name=mikbill_auto_global parent=global priority=1 queue=default \n");	
				break;
			}
			
			default:
				break;
		}
		return $rules;
	}
	
	public function add_queue_tree_tarif($addr_list)
	{
		$rules=array();
		
		array_push($rules, "/queue tree\n");
		array_push($rules, "add name=mikbill_auto-{$addr_list} parent=mikbill_auto_global priority=1 queue=default \n");
		array_push($rules, "add name=mikbill_auto-{$addr_list}-IN parent=mikbill_auto-{$addr_list} priority=1 queue=default \n");
		array_push($rules, "add name=mikbill_auto-{$addr_list}-OUT parent=mikbill_auto-{$addr_list} priority=1 queue=default \n");
		
		return $rules;
	}
	
	public function add_queue_tree_interval($addr_list, $start, $stop, $disabled, $interval, $priority)
	{
		$rules=array();
		
		if($priority == 0)
			$priority = 1;
		
		array_push($rules, "/queue tree\n");
		array_push($rules, "add burst-limit=0 burst-threshold=0 burst-time=0s disabled={$disabled} limit-at=0 max-limit=0 parent=mikbill_auto-{$addr_list}-IN \\\n");
		array_push($rules, "	name=mikbill_auto-{$addr_list}-rx_interval_{$start}-{$stop} packet-mark={$addr_list}-IN priority={$priority} queue=mikbill_auto-{$addr_list}-IN{$interval} \n");
		array_push($rules, "add burst-limit=0 burst-threshold=0 burst-time=0s disabled={$disabled} limit-at=0 max-limit=0 parent=mikbill_auto-{$addr_list}-OUT \\\n");
		array_push($rules, "	name=mikbill_auto-{$addr_list}-tx_interval_{$start}-{$stop} packet-mark={$addr_list}-OUT priority={$priority} queue=mikbill_auto-{$addr_list}-OUT{$interval} \n");

		return $rules;
	}
	
	public function add_sheduler($addr_list, $start, $stop)
	{
		$rules=array();
		
		array_push($rules, "/system scheduler\n");
		array_push($rules, "add disabled=no interval=1d name=mikbill_auto_{$addr_list}_enable_interval_{$start}-{$stop} on-event=\"\\\n");
		array_push($rules, ":log warning \\\"[mikbill interval] enable {$addr_list} interval {$start}-{$stop} \\\"\r\n");
		array_push($rules, "/queue tree enable mikbill_auto-{$addr_list}-rx_interval_{$start}-{$stop}\r\n");
		array_push($rules, "/queue tree enable mikbill_auto-{$addr_list}-tx_interval_{$start}-{$stop}\" \\\n");  
		array_push($rules, "policy=read,write start-date=jan/01/1970 start-time={$start}:00:00 \n");
		
		array_push($rules, "add disabled=no interval=1d name=mikbill_auto_{$addr_list}_disable_interval_{$start}-{$stop} on-event=\"\\\n");
		array_push($rules, ":log warning \\\"[mikbill interval] disable {$addr_list} interval {$start}-{$stop} \\\"\r\n");
		array_push($rules, "/queue tree disable mikbill_auto-{$addr_list}-rx_interval_{$start}-{$stop}\r\n");
		array_push($rules, "/queue tree disable mikbill_auto-{$addr_list}-tx_interval_{$start}-{$stop}\" \\\n");  
		array_push($rules, "policy=read,write start-date=jan/01/1970 start-time={$stop}:00:00 \n");
		
		return $rules;
	}
	
	public function add_queue_tree_leaf($addr_list, $country, $priority)
	{
		$rules=array();
		
		if($priority == 0)
			$priority = 1;
			
		array_push($rules, "/queue tree\n");
		array_push($rules, "add burst-limit=0 burst-threshold=0 burst-time=0s disabled=no limit-at=0 max-limit=0 parent=mikbill_auto-{$addr_list}-IN \\\n");
		array_push($rules, "    name=mikbill_auto-{$addr_list}-rx{$country} packet-mark={$addr_list}-IN{$country} priority={$priority} queue=mikbill_auto-{$addr_list}-IN{$country} \n");
		array_push($rules, "add burst-limit=0 burst-threshold=0 burst-time=0s disabled=no limit-at=0 max-limit=0 parent=mikbill_auto-{$addr_list}-OUT \\\n");                                             
		array_push($rules, "    name=mikbill_auto-{$addr_list}-tx{$country} packet-mark={$addr_list}-OUT{$country} priority={$priority} queue=mikbill_auto-{$addr_list}-OUT{$country} \n");
		
		return $rules;
	}
	
	public function create_queue_simple($addr_list, $mark, $interval, $start, $stop, $priority)
	{
		$rules=array();
		
		if($priority == 0)
			$priority = 1;
		
		switch($this->mk_ver)
		{
			//5.x
			case 1:
			{
				array_push ( $rules, "/queue simple\n" );
				array_push ( $rules, "add disabled=no burst-limit=0/0 burst-threshold=0/0 burst-time=0s/0s limit-at=0/0 max-limit=0/0 parent=none interface=all total-queue=default-small \\\n" );
				array_push ( $rules, "    time={$start}-{$stop},sun,mon,tue,wed,thu,fri,sat target-addresses=\"{$this->network_list}\" packet-marks={$addr_list}-IN{$mark},{$addr_list}-OUT{$mark} \\\n" );
				array_push ( $rules, "    comment=mikbill_auto-{$addr_list}-IN{$interval} name=mikbill_auto-{$addr_list}{$interval} \\\n" );
				array_push ( $rules, "    queue=mikbill_auto-{$addr_list}-OUT{$interval}/mikbill_auto-{$addr_list}-IN{$interval} priority={$priority} \n" );
				break;
			}
			//6.x
			case 2:
			{
				array_push ( $rules, "/queue simple\n" );
				array_push ( $rules, "add disabled=no burst-limit=0/0 burst-threshold=0/0 burst-time=0s/0s limit-at=0/0 max-limit=0/0 parent=none total-queue=default-small \\\n" );
				array_push ( $rules, "    time={$start}-{$stop},sun,mon,tue,wed,thu,fri,sat target=\"{$this->network_list}\" packet-marks={$addr_list}-IN{$mark},{$addr_list}-OUT{$mark} \\\n" );
				array_push ( $rules, "    comment=mikbill_auto-{$addr_list}{$interval} name=mikbill_auto-{$addr_list}{$interval} \\\n" );
				array_push ( $rules, "    queue=mikbill_auto-{$addr_list}-OUT{$interval}/mikbill_auto-{$addr_list}-IN{$interval} priority={$priority}/{$priority} \n" );
				break;
			}
			
			default:
				break;
		}
		
		return $rules;
	}
}
?>